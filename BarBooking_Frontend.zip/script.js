function toggleForm() {
    document.getElementById('reservaForm').classList.toggle('hidden');
    document.getElementById('chatbot').classList.toggle('hidden');
}

async function enviarReserva(event) {
    event.preventDefault();
    const form = event.target;
    const dados = new FormData(form);
    const params = new URLSearchParams(dados);

    const resposta = await fetch("https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec", {
        method: "POST",
        body: params,
    });

    const texto = await resposta.text();
    document.getElementById("resposta").textContent = texto;
    form.reset();
    toggleForm();
}